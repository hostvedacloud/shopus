import React from "react";
import OrderCom from "../../../src/components/OrderCom";
function orderDetailsPage() {
  return (
    <>
      <OrderCom />
    </>
  );
}
export default orderDetailsPage;
